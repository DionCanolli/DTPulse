package com.dioncanolli.dtpulse_back_end.dto;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class TransactionInsertingDTO {
    private List<String> products;

    public TransactionInsertingDTO(List<String> products) {
        this.products = products;
    }

    public TransactionInsertingDTO() {
    }
}
