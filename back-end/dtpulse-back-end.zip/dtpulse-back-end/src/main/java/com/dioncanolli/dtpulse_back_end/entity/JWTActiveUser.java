package com.dioncanolli.dtpulse_back_end.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Getter
@Setter
@Entity
@Table(name = "JWTActiveUsers")
public class JWTActiveUser {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "theId")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    private String jwtToken;

    public JWTActiveUser(Long id, User user, String lastJwtToken) {
        this.id = id;
        this.user = user;
        this.jwtToken = lastJwtToken;
    }

    public JWTActiveUser(User user, String lastJwtToken) {
        this.user = user;
        this.jwtToken = lastJwtToken;
    }

    public JWTActiveUser() {
    }
}
