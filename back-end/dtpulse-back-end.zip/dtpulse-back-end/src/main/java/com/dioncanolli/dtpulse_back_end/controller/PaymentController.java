package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.dto.PaymentDTO;
import com.dioncanolli.dtpulse_back_end.dto.TransactionDTO;
import com.dioncanolli.dtpulse_back_end.entity.Transaction;
import com.dioncanolli.dtpulse_back_end.entity.User;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import com.dioncanolli.dtpulse_back_end.utility.JWTTokenGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/payments")
public class PaymentController {

    private final MyService myService;

    public PaymentController(MyService myService) {
        this.myService = myService;
    }

    @PostMapping("/process")
    public ResponseEntity<String> processPayment(@RequestBody PaymentDTO paymentDTO, @RequestHeader(value = "Authorization") String jwtToken) {

        String email = JWTTokenGenerator.extractUsernameFromToken(jwtToken);
        User user = myService.findUserByEmail(email);

        // Call the service method to process the payment
        String paymentResponse = myService.processPayment(paymentDTO, user);

        // Return the response to the frontend
        if (paymentResponse.contains("Error")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(paymentResponse);
        }

        return ResponseEntity.status(HttpStatus.CREATED).body(paymentResponse);
    }
}
