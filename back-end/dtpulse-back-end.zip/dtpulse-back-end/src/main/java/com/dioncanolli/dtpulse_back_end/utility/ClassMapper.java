package com.dioncanolli.dtpulse_back_end.utility;

import com.dioncanolli.dtpulse_back_end.dto.*;
import com.dioncanolli.dtpulse_back_end.entity.*;
import com.dioncanolli.dtpulse_back_end.service.MyService;

import java.util.List;


public class ClassMapper {

    private final MyService myService;

    public ClassMapper(MyService myService) {
        this.myService = myService;
    }

    /*
        1.  Map to CartDTO  +
        2.  Map to Cart  +
        3.  Map to ProductDTO  +
        5.  Map to ReviewDTO +
        7.  Map to TransactionDTO +
        9.  Map to UserDTO +
        11. Map to WishlistDTO +
     */

    public static CartDTO mapToCartDTO(CartItem cartItem){
        return CartDTO.builder()
                .username(cartItem.getUser().getUsername())
                .email(cartItem.getUser().getEmail())
                .productName(cartItem.getProduct().getProductName())
                .productCategory(cartItem.getProduct().getCategory().getCategoryName())
                .productPrice(cartItem.getProduct().getProductPrice())
                .quantity(cartItem.getQuantity())
                .totalPrice(cartItem.getQuantity() * cartItem.getProduct().getProductPrice())
                .build();
    }

//    public CartItem mapToCart(CartDTO cartDTO){
//        return CartItem.builder()
//                .user(myService.findUserByEmail(cartDTO.getEmail()))
//                .product(myService.findProductByProductName(cartDTO.getProductName()))
//                .quantity(cartDTO.getQuantity())
//                .build();
//    }

    public static ProductDTO mapToProductDTO(Product product){
        List<Rating> productReviews = product.getReviews();
        double rating = 0;
        int count = 0;

        for (Rating r : productReviews){
            rating += r.getRating();
            count++;
        }
        if (count > 0) rating /= count;

        return ProductDTO.builder()
                .productId(product.getId())
                .productName(product.getProductName())
                .productDescription(product.getProductDescription())
                .productCategory(product.getCategory().getCategoryName())
                .productImageUrl(product.getProductImageUrl())
                .productPrice(product.getProductPrice())
                .productStockQuantity(product.getProductStockQuantity())
                .rating(rating)
                .build();
    }

    public static RatingDTO mapToReviewDTO(Rating review){
        return RatingDTO.builder()
                .id(review.getId())
                .productName(review.getProduct().getProductName())
                .userEmail(review.getUser().getEmail())
                .rating(review.getRating())
                .build();
    }

    public static UserDTO mapToUserDTO(User user){
        return UserDTO.builder()
                .userId(user.getId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .username(user.getUsername())
                .email(user.getEmail())
                .phoneNumber(user.getPhoneNumber())
                .build();
    }

    public static WishlistDTO mapToWishlistDTO(WishlistItem wishlistItem){
        return WishlistDTO.builder()
                .username(wishlistItem.getUser().getUsername())
                .email(wishlistItem.getUser().getEmail())
                .productName(wishlistItem.getProduct().getProductName())
                .productCategory(wishlistItem.getProduct().getCategory().getCategoryName())
                .productPrice(wishlistItem.getProduct().getProductPrice())
                .build();
    }
}





























