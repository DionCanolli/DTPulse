package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.dto.ProductDTO;
import com.dioncanolli.dtpulse_back_end.dto.RatingDTO;
import com.dioncanolli.dtpulse_back_end.entity.Category;
import com.dioncanolli.dtpulse_back_end.entity.User;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/permitted")
public class PermittedRequestsController {

    private final MyService myService;

    public PermittedRequestsController(MyService myService) {
        this.myService = myService;
    }

    @PostMapping(value = "/users/signup")
    public ResponseEntity<Boolean> signUp(@RequestBody User user){
        boolean result = myService.insertUser(user);
        return !result
                ? new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.CREATED);
    }

    @GetMapping(value = "/products/all")
    public ResponseEntity<List<ProductDTO>> findAllProductsPaginated(@RequestParam int page){
        List<ProductDTO> productDTOS = myService.findAllProductsPaginated(page);
        if (productDTOS != null)
                return (productDTOS.isEmpty())? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(productDTOS, HttpStatus.OK);
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    @GetMapping(value = "/products/category")
    public ResponseEntity<List<ProductDTO>> findAllProductsByCategoryPaginated(@RequestParam String categoryName, @RequestParam int page){
        List<ProductDTO> productDTOS = myService.findAllProductsByCategoryPaginated(categoryName, page);
        if (productDTOS != null)
            return (productDTOS.isEmpty())? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(productDTOS, HttpStatus.OK);
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);    }

    @GetMapping(value = "/products/find/dto")
    public ResponseEntity<ProductDTO> findProductByProductDTOByName(@RequestParam String productName){
        ProductDTO productDTO = myService.findProductDTOByProductName(productName);
        return (productDTO == null) ? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(productDTO, HttpStatus.OK);
    }

    @GetMapping(value = "/products/find")
    public ResponseEntity<ProductDTO> findProductByProductByName(@RequestParam String productName){
        ProductDTO productDTO = myService.findProductDTOByProductName(productName);
        return (productDTO == null) ? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(productDTO, HttpStatus.OK);
    }

    @GetMapping(value = "/products/name-and-category")
    public ResponseEntity<List<ProductDTO>> findAllProductsByCategoryAndProductName(@RequestParam String categoryName,
                                                                                    @RequestParam String productName,
                                                                                    @RequestParam int page){
        List<ProductDTO> productDTOS = myService.findAllProductsByCategoryAndProductName(categoryName, productName, page);
        if (productDTOS != null)
            return (productDTOS.isEmpty())? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(productDTOS, HttpStatus.OK);
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    @GetMapping(value = "/categories/all")
    public ResponseEntity<List<Category>> findAllCategories(){
        List<Category> categories = myService.findAllCategories();
        return (categories.isEmpty()) ? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(categories, HttpStatus.OK);
    }

    @GetMapping(value = "/ratings/product")
    public ResponseEntity<Double> findAllReviewsByProduct(@RequestParam String productName){
        List<RatingDTO> ratingDTOS = myService.findAllRatingsByProduct(productName);
        if (ratingDTOS != null){
            double rating = 0.0;
            for (RatingDTO ratingDTO : ratingDTOS){
                rating += ratingDTO.getRating();
            }
            return (ratingDTOS.isEmpty())? new ResponseEntity<>(0.0, HttpStatus.OK) : new ResponseEntity<>(rating, HttpStatus.OK);
        }
        return new ResponseEntity<>(0.0, HttpStatus.OK);
    }
}
