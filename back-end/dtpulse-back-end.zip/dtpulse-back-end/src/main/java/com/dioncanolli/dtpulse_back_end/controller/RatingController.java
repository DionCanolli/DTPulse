package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.dto.RatingDTO;
import com.dioncanolli.dtpulse_back_end.entity.User;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import com.dioncanolli.dtpulse_back_end.utility.JWTTokenGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/ratings")
public class RatingController {

    private final MyService myService;

    public RatingController(MyService myService) {
        this.myService = myService;
    }

    @PostMapping(value = "/insert")
    public ResponseEntity<Boolean> insertReview(@RequestHeader(value = "Authorization") String jwtToken, @RequestBody RatingDTO ratingDTO){
        ratingDTO.setUserEmail(JWTTokenGenerator.extractUsernameFromToken(jwtToken));
        boolean result = myService.insertRating(ratingDTO);
        return !result ?
                new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.CREATED);
    }

    @DeleteMapping(value = "/delete")
    public ResponseEntity<Boolean> deleteReview(@RequestHeader(value = "Authorization") String jwtToken, @RequestParam String productName){
        boolean result = myService.deleteRating(JWTTokenGenerator.extractUsernameFromToken(jwtToken), productName);
        return !result ?
                new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.OK);
    }
}










