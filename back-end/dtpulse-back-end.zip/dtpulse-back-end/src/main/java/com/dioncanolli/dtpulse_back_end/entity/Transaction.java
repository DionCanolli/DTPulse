package com.dioncanolli.dtpulse_back_end.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.sql.Timestamp;

@Entity
@Table(name = "Transactions")
@Getter
@Setter
@Builder
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "transactionId")
    private Long id;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "productId")
    private Product product;

    private Timestamp dateTimeOfTransaction;

    public Transaction(Long id, User user, Product product, Timestamp dateTimeOfTransaction) {
        this.id = id;
        this.user = user;
        this.product = product;
        this.dateTimeOfTransaction = dateTimeOfTransaction;
    }

    public Transaction(User user, Product product, Timestamp dateTimeOfTransaction) {
        this.user = user;
        this.product = product;
        this.dateTimeOfTransaction = dateTimeOfTransaction;
    }

    public Transaction(User user, Product product) {
        this.user = user;
        this.product = product;
    }

    public Transaction() {
    }
}
