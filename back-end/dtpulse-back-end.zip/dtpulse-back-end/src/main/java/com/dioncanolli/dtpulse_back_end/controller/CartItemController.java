package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.dto.CartDTO;
import com.dioncanolli.dtpulse_back_end.dto.TransactionDTO;
import com.dioncanolli.dtpulse_back_end.dto.WishlistDTO;
import com.dioncanolli.dtpulse_back_end.entity.CartItem;
import com.dioncanolli.dtpulse_back_end.entity.User;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import com.dioncanolli.dtpulse_back_end.utility.JWTTokenGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/cart")
public class CartItemController {

    private final MyService myService;

    public CartItemController(MyService myService) {
        this.myService = myService;
    }

    @GetMapping(value = "/user")
    public ResponseEntity<List<CartDTO>> findAllCartItemsByUser(@RequestHeader(value = "Authorization") String jwtToken){
        List<CartDTO> cartDTOS = myService.findAllCartItemsByUser(JWTTokenGenerator.extractUsernameFromToken(jwtToken));
        if (cartDTOS != null){
            return cartDTOS.isEmpty() ? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(cartDTOS, HttpStatus.OK);
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    @PostMapping(value = "/insert")
    public ResponseEntity<Boolean> insertCartItem(@RequestHeader(value = "Authorization") String jwtToken, @RequestParam String productName){
        if (jwtToken != null) {
            String email = JWTTokenGenerator.extractUsernameFromToken(jwtToken);
            User user = myService.findUserByEmail(email);
            boolean result = myService.insertCartItem(user, productName);
            return !result ? new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(false, HttpStatus.OK);
    }

    @DeleteMapping(value = "/delete")
    public ResponseEntity<Boolean> deleteCartItem(@RequestHeader(value = "Authorization") String jwtToken, @RequestParam String productName){
        if (jwtToken != null) {
            String email = JWTTokenGenerator.extractUsernameFromToken(jwtToken);
            User user = myService.findUserByEmail(email);
            boolean result = myService.deleteCartItem(user, productName);
            return !result ? new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.OK);
        }
        return new ResponseEntity<>(false, HttpStatus.OK);
    }
}
























