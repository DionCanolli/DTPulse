package com.dioncanolli.dtpulse_back_end.dto;

import com.dioncanolli.dtpulse_back_end.entity.Product;
import com.dioncanolli.dtpulse_back_end.entity.User;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;
import java.util.List;

@Getter
@Setter
@Builder
public class TransactionDTO {
    private String userEmail;
    private String productName;
    private double amount;
    private Timestamp dateOfPurchase;

    public TransactionDTO(String userEmail, String productName, double amount, Timestamp dateOfPurchase) {
        this.userEmail = userEmail;
        this.productName = productName;
        this.amount = amount;
        this.dateOfPurchase = dateOfPurchase;
    }

    public TransactionDTO(String userEmail, String productName, double amount) {
        this.userEmail = userEmail;
        this.productName = productName;
        this.amount = amount;
    }

    public TransactionDTO() {
    }
}
