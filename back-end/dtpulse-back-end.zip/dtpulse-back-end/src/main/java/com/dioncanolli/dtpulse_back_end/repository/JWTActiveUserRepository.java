package com.dioncanolli.dtpulse_back_end.repository;

import com.dioncanolli.dtpulse_back_end.entity.JWTActiveUser;
import com.dioncanolli.dtpulse_back_end.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JWTActiveUserRepository extends JpaRepository<JWTActiveUser, Long> {
    JWTActiveUser findByJwtTokenAndUser_Email(String jwtToken, String email);
}
