package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.entity.Category;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/categories")
public class CategoryController {

    private final MyService myService;

    public CategoryController(MyService myService) {
        this.myService = myService;
    }

    @GetMapping(value = "/permitted/all")
    public ResponseEntity<List<Category>> findAllCategories(){
        List<Category> categories = myService.findAllCategories();
        return (categories.isEmpty()) ? new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(categories, HttpStatus.OK);
    }
}
