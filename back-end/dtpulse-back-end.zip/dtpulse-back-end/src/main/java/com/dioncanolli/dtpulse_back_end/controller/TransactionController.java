package com.dioncanolli.dtpulse_back_end.controller;

import com.dioncanolli.dtpulse_back_end.dto.TransactionDTO;
import com.dioncanolli.dtpulse_back_end.dto.TransactionInsertingDTO;
import com.dioncanolli.dtpulse_back_end.entity.Product;
import com.dioncanolli.dtpulse_back_end.entity.Transaction;
import com.dioncanolli.dtpulse_back_end.entity.User;
import com.dioncanolli.dtpulse_back_end.service.MyService;
import com.dioncanolli.dtpulse_back_end.utility.JWTTokenGenerator;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class TransactionController {

    private final MyService myService;

    public TransactionController(MyService myService) {
        this.myService = myService;
    }

    @GetMapping(value = "/admin/transactions/all")
    public ResponseEntity<List<TransactionDTO>> findAllTransactions(){
        List<Transaction> transactions = myService.findAllTransactions();
        List<TransactionDTO> transactionDTOS = new ArrayList<>();

        transactions.forEach(transaction -> transactionDTOS.add(
                new TransactionDTO(
                        transaction.getUser().getEmail(),
                        transaction.getProduct().getProductName(),
                        transaction.getProduct().getProductPrice(),
                        transaction.getDateTimeOfTransaction())));

        return (transactionDTOS.isEmpty()) ?
                new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(transactionDTOS, HttpStatus.OK);
    }

    @GetMapping(value = "/transactions/user")
    public ResponseEntity<List<TransactionDTO>> findAllTransactions(@RequestHeader(value = "Authorization") String jwtToken){
        List<Transaction> transactions = myService.findAllTransactionsByUserEmail(JWTTokenGenerator.extractUsernameFromToken(jwtToken));
        List<TransactionDTO> transactionDTOS = new ArrayList<>();

        transactions.forEach(transaction -> transactionDTOS.add(
                new TransactionDTO(
                        transaction.getUser().getEmail(),
                        transaction.getProduct().getProductName(),
                        transaction.getProduct().getProductPrice(),
                        transaction.getDateTimeOfTransaction())));

        return (transactionDTOS.isEmpty()) ?
                new ResponseEntity<>(null, HttpStatus.NOT_FOUND) : new ResponseEntity<>(transactionDTOS, HttpStatus.OK);
    }

    @PostMapping(value = "/transactions/insert")
    public ResponseEntity<Boolean> insertTransaction(@RequestHeader(required = false, value = "Authorization") String jwtToken,
                                                     @RequestBody TransactionInsertingDTO transactionInsertingDTO){
        boolean result = false;
        if (jwtToken != null) {
            String email = JWTTokenGenerator.extractUsernameFromToken(jwtToken);
            User user = myService.findUserByEmail(email);

            List<String> productsNames = transactionInsertingDTO.getProducts();
            for (String productName : productsNames) {
                Product product = myService.findProductByProductName(productName);
                if (product != null){
                    result = myService.insertTransaction(new TransactionDTO(user.getEmail(), productName, product.getProductPrice()));
                    if (!result){
                        break;
                    }
                }
            }
            return !result ?
                    new ResponseEntity<>(false, HttpStatus.BAD_REQUEST) : new ResponseEntity<>(true, HttpStatus.CREATED);
        }
        return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
    }
}
