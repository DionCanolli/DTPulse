package com.dioncanolli.dtpulse_back_end.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RatingDTO {
    private Long id;
    private String userEmail;
    private String productName;
    private double rating;

    public RatingDTO(Long id, String userEmail, String productName, double rating) {
        this.id = id;
        this.userEmail = userEmail;
        this.productName = productName;
        this.rating = rating;
    }

    public RatingDTO(String userEmail, String productName, double rating) {
        this.userEmail = userEmail;
        this.productName = productName;
        this.rating = rating;
    }

    public RatingDTO(String productName, double rating) {
        this.productName = productName;
        this.rating = rating;
    }

    public RatingDTO() {
    }
}
