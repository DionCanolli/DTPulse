package com.dioncanolli.dtpulse_back_end.dto;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class CartDTO {
    private String username;
    private String email;
    private String productName;
    private String productCategory;
    private double productPrice;
    private int quantity;
    private double totalPrice;

    public CartDTO(String username, String email, String productName, String productCategory, double productPrice, int quantity, double totalPrice) {
        this.username = username;
        this.email = email;
        this.productName = productName;
        this.productCategory = productCategory;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
    }

    public CartDTO(String productName, String productCategory, double productPrice, int quantity, double totalPrice) {
        this.productName = productName;
        this.productCategory = productCategory;
        this.productPrice = productPrice;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
    }

    public CartDTO(String productName, String productCategory, double productPrice, int quantity) {
        this.productName = productName;
        this.productCategory = productCategory;
        this.productPrice = productPrice;
        this.quantity = quantity;
    }

    public CartDTO(String productName, int quantity) {
        this.productName = productName;
        this.quantity = quantity;
    }


    public CartDTO() {
    }
}
