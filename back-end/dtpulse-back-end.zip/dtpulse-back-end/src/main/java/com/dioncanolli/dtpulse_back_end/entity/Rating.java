package com.dioncanolli.dtpulse_back_end.entity;

import jakarta.persistence.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "Ratings")
@Getter
@Setter
@Builder
public class Rating {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ratingId")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @ManyToOne
    @JoinColumn(name = "productId")
    private Product product;

    private double rating;

    public Rating(Long id, User user, Product product, double rating) {
        this.id = id;
        this.user = user;
        this.product = product;
        this.rating = rating;
    }

    public Rating(User user, Product product, double rating) {
        this.user = user;
        this.product = product;
        this.rating = rating;
    }

    public Rating() {
    }
}
