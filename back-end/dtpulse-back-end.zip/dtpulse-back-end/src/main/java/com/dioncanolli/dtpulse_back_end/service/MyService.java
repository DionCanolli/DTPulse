package com.dioncanolli.dtpulse_back_end.service;

import com.dioncanolli.dtpulse_back_end.dto.*;
import com.dioncanolli.dtpulse_back_end.entity.*;
import com.dioncanolli.dtpulse_back_end.repository.*;
import com.dioncanolli.dtpulse_back_end.utility.ClassMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.util.*;

@Service
public class MyService {

    @Lazy
    @Autowired
    private PasswordEncoder passwordEncoder;

    private final CartItemRepository cartItemRepository;
    private final CategoryRepository categoryRepository;
    private final PaymentRepository paymentRepository;
    private final ProductRepository productRepository;
    private final RatingRepository ratingRepository;
    private final RoleRepository roleRepository;
    private final TransactionRepository transactionRepository;
    private final UserRepository userRepository;
    private final WishlistItemRepository wishlistItemRepository;
    private final JWTTokenBlacklistRepository jwtTokenBlacklistRepository;
    private final JWTActiveUserRepository jwtActiveUserRepository;

    @Value("${checkout.secret.key}")
    private String checkoutSecretKey;
    private final String paymentUrl = "https://api.sandbox.checkout.com/payments";

    public MyService(CartItemRepository cartItemRepository, CategoryRepository categoryRepository, PaymentRepository paymentRepository, ProductRepository productRepository, RatingRepository ratingRepository, RoleRepository roleRepository, TransactionRepository transactionRepository, UserRepository userRepository, WishlistItemRepository wishlistItemRepository, JWTTokenBlacklistRepository jwtTokenBlacklistRepository, JWTActiveUserRepository jwtActiveUserRepository) {
        this.cartItemRepository = cartItemRepository;
        this.categoryRepository = categoryRepository;
        this.paymentRepository = paymentRepository;
        this.productRepository = productRepository;
        this.ratingRepository = ratingRepository;
        this.roleRepository = roleRepository;
        this.transactionRepository = transactionRepository;
        this.userRepository = userRepository;
        this.wishlistItemRepository = wishlistItemRepository;
        this.jwtTokenBlacklistRepository = jwtTokenBlacklistRepository;
        this.jwtActiveUserRepository = jwtActiveUserRepository;
    }

    public List<Category> findAllCategories(){
        return categoryRepository.findAll();
    }

    public List<ProductDTO> findAllProductsPaginated(int page){
        Pageable pageable = PageRequest.of(page, 20);
        Page<Product> products = productRepository.findAll(pageable);
        List<ProductDTO> productDTOs = new ArrayList<>();

        for (Product product : products){
            productDTOs.add(ClassMapper.mapToProductDTO(product));
        }
        return (productDTOs.isEmpty()) ? null : productDTOs;
    }

    public List<ProductDTO> findAllProductsByCategoryPaginated(String categoryName, int page){
        Category category = categoryRepository.findCategoryByCategoryName(categoryName);
        if (category == null) {
            return null;
        }
        Pageable pageable = PageRequest.of(page, 20);
        Page<Product> products = productRepository.findAllProductsByCategory(category, pageable);
        List<ProductDTO> productDTOs = new ArrayList<>();

        for (Product product : products){
            productDTOs.add(ClassMapper.mapToProductDTO(product));
        }
        return (productDTOs.isEmpty()) ? null : productDTOs;
    }

    public ProductDTO findProductDTOByProductName(String productName){
        Product product = productRepository.findProductByProductName(productName);
        return (product == null) ? null : ClassMapper.mapToProductDTO(product);
    }

    public Product findProductByProductName(String productName){
        return productRepository.findProductByProductName(productName);
    }

    public List<ProductDTO> findAllProductsByCategoryAndProductName(String categoryName, String productName, int page){
        Category category = categoryRepository.findCategoryByCategoryName(categoryName);
        if (category == null) {
            return null;
        }
        Pageable pageable = PageRequest.of(page, 20);
        Page<Product> products = productRepository
                .findAllProductsByCategoryAndProductNameIgnoreCase(category, productName, pageable);
        List<ProductDTO> productDTOs = new ArrayList<>();

        for (Product product : products){
            productDTOs.add(ClassMapper.mapToProductDTO(product));
        }
        return (productDTOs.isEmpty()) ? null : productDTOs;
    }

    public List<UserDTO> findAllUsers(){
        List<User> users = userRepository.findAll();
        List<UserDTO> userDTOs = new ArrayList<>();

        for (User user : users){
            userDTOs.add(ClassMapper.mapToUserDTO(user));
        }
        return (userDTOs.isEmpty()) ? null : userDTOs;
    }

    public List<Transaction> findAllTransactions(){
        List<Transaction> transactions = transactionRepository.findAll();
        if (transactions != null){
            return (transactions.isEmpty()) ? null : transactions;
        }
        return null;
    }

    public List<Transaction> findAllTransactionsByUserEmail(String userEmail){
        List<Transaction> transactions = transactionRepository.findByUser_Email(userEmail);
        if (transactions != null){
            return (transactions.isEmpty()) ? null : transactions;
        }
        return null;
    }

    public List<RatingDTO> findAllRatingsByProduct(String productName){
        Product product = findProductByProductName(productName);
        if (product == null){
            return null;
        }
        List<Rating> reviews = ratingRepository.findAllReviewsByProduct(product);
        List<RatingDTO> ratingDTOS = new ArrayList<>();

        for (Rating review : reviews){
            ratingDTOS.add(ClassMapper.mapToReviewDTO(review));
        }
        return (ratingDTOS.isEmpty()) ? null : ratingDTOS;
    }

    public List<WishlistDTO> findAllWishlistItemsByUser(String userEmail){
        User user = findUserByEmail(userEmail);
        if (user == null){
            return null;
        }
        List<WishlistItem> wishlistItems = wishlistItemRepository.findAllWishlistItemsByUser(user);
        List<WishlistDTO> wishlistDTOs = new ArrayList<>();

        for (WishlistItem wishlistItem : wishlistItems){
            wishlistDTOs.add(ClassMapper.mapToWishlistDTO(wishlistItem));
        }
        return (wishlistDTOs.isEmpty()) ? null : wishlistDTOs;
    }

    public UserDTO findUserDTOByEmail(String email){
        User user = userRepository.findByEmail(email);
        return (user == null) ? null : ClassMapper.mapToUserDTO(user);
    }

    public User findUserByEmail(String email){
        return userRepository.findByEmail(email);
    }

    public boolean insertUser(User user){
        if (findUserByEmail(user.getEmail()) == null){
            user.setRole(roleRepository.findByRoleName("ROLE_USER"));
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            userRepository.save(user);
            return true;
        }
        return false;
    }

    public boolean insertProduct(ProductDTO productDTO, MultipartFile productImage){
        Category category = categoryRepository.findCategoryByCategoryName(productDTO.getProductCategory());
        if (category == null) return false;


        if (findProductByProductName(productDTO.getProductName()) == null){

            File directory = new File(productDTO.getProductImageUrl());
            String fileExtension = StringUtils.getFilenameExtension(productImage.getOriginalFilename());
            String finalImageUrl = directory.getAbsolutePath() + File.separator + productDTO.getProductName() + "." + fileExtension;

            File imageFile = new File(finalImageUrl);

            Product product = new Product(productDTO.getProductName(), productDTO.getProductDescription(), productDTO.getProductPrice(),
                    productDTO.getProductStockQuantity(), finalImageUrl, category);

            try{
                productRepository.save(product);
                productImage.transferTo(imageFile);
                return true;
            }catch (IOException e){
                System.out.println(e.getMessage());
            }
        }
        return false;
    }

    public boolean wishlistItemUserAndProductExists(User user, Product product){
        WishlistItem wishlistItem = wishlistItemRepository.findByUserAndProduct(user, product);
        return wishlistItem != null;
    }

    public boolean insertWishtlistItem(User user, String productName){
        Product product = findProductByProductName(productName);
        if (user != null && product != null && !wishlistItemUserAndProductExists(user, product)){
            wishlistItemRepository.save(new WishlistItem(user, product));
            return true;
        }
        return false;
    }

    public boolean insertCartItem(User user, String productName){
        Product product = findProductByProductName(productName);
        if (user != null && product != null && cartItemRepository.findByUserAndProduct(user, product) == null){
            cartItemRepository.save(new CartItem(user, product, product.getProductStockQuantity()));
            return true;
        }
        return false;
    }

    public boolean insertRating(RatingDTO ratingDTO){
        User user = findUserByEmail(ratingDTO.getUserEmail());
        Product product = findProductByProductName(ratingDTO.getProductName());
        if (user != null && product != null){
            List<Transaction> transactions = transactionRepository.findByUserAndProduct(user, product);
            if(transactions != null){
                if (!transactions.isEmpty()){
                    if(ratingRepository.findByUserAndProduct(user, product) == null){
                        ratingRepository.save(new Rating(user, product, ratingDTO.getRating()));
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean insertTransaction(TransactionDTO transactionDTO){
        User user = findUserByEmail(transactionDTO.getUserEmail());
        Product product = findProductByProductName(transactionDTO.getProductName());
        if(user == null || product == null) return false;

        transactionRepository.save(new Transaction(user, product, returnLastUserPaymentTimestamp(user)));
        return true;
    }

    // Emailen nuk mun e ndryshon
    public boolean modifyUser(User user){
        User userFound = findUserByEmail(user.getEmail());
        if (userFound != null){
            userFound.setFirstName(user.getFirstName());
            userFound.setLastName(user.getLastName());
            userFound.setPhoneNumber(user.getPhoneNumber());
            userFound.setPassword(passwordEncoder.encode(user.getPassword()));
            userRepository.save(userFound);
            return true;
        }
        return false;
    }

    public boolean modifyProduct(ProductDTO productDTO, MultipartFile newProductImage) throws IOException {
        Optional<Product> productFoundOptional = productRepository.findById(productDTO.getProductId());
        if (productFoundOptional.isPresent()){
            // delete old product image
            Files.deleteIfExists(Paths.get(productDTO.getProductImageUrl() + File.separator + productFoundOptional.get().getProductName()));

            // Me shtu imagen e re te produktit
            File directory = new File(productDTO.getProductImageUrl() + File.separator + productDTO.getProductName());
            String fileExtension = StringUtils.getFilenameExtension(newProductImage.getOriginalFilename());
            File imageFile = new File(directory.getAbsolutePath() + "." + fileExtension);
            newProductImage.transferTo(imageFile);

            Product productFound = productFoundOptional.get();
            productFound.setProductName(productDTO.getProductName());
            productFound.setProductDescription(productDTO.getProductDescription());
            productFound.setProductPrice(productDTO.getProductPrice());
            productFound.setProductStockQuantity(productDTO.getProductStockQuantity());
            productFound.setProductImageUrl(directory.getAbsolutePath() + "." + fileExtension);
            productRepository.save(productFound);
            return true;
        }
        return false;
    }

    public boolean deleteUser(String userEmail){
        User userFound = findUserByEmail(userEmail);
        if (userFound != null){
            userRepository.delete(userFound);
            return true;
        }
        return false;
    }

    public boolean deleteProduct(String productName) throws IOException {
        Product productFound = findProductByProductName(productName);
        if (productFound != null){
            Files.deleteIfExists(Paths.get(productFound.getProductImageUrl()));
            productRepository.delete(productFound);
            return true;
        }
        return false;
    }

    public boolean deleteWishlistItem(String userEmail, String productName){
        User userFound = findUserByEmail(userEmail);
        Product productFound = findProductByProductName(productName);
        WishlistItem wishlistItem = wishlistItemRepository.findByUserAndProduct(userFound, productFound);

        if (wishlistItem != null){
            wishlistItemRepository.delete(wishlistItem);
            return true;
        }
        return false;
    }

    public boolean deleteCartItem(User user, String productName){
        Product productFound = findProductByProductName(productName);
        CartItem cartItem = cartItemRepository.findByUserAndProduct(user, productFound);
        if (cartItem != null){
            cartItemRepository.delete(cartItem);
            return true;
        }
        return false;
    }

    public boolean deleteRating(String userEmail, String productName){
        User userFound = findUserByEmail(userEmail);
        Product productFound = findProductByProductName(productName);
        Rating review = ratingRepository.findByUserAndProduct(userFound, productFound);
        if (review != null){
            ratingRepository.delete(review);
            return true;
        }
        return false;
    }

    public boolean isTokenBlacklisted(String value){
        return jwtTokenBlacklistRepository.findByJwtValue(value) != null;
    }

    public void createJWTActiveUser(String email, String jwtToken){
        User user = findUserByEmail(email);
        if(user != null){
            jwtActiveUserRepository.save(new JWTActiveUser(user, jwtToken));
        }
    }

    public JWTActiveUser findJWTActiveUserByUserEmailAndJWTToken(String email, String jwtToken){
        return jwtActiveUserRepository.findByJwtTokenAndUser_Email(jwtToken, email);
    }

    public boolean deleteJWTActiveUserAndBlacklistJWTToken(String email, String jwtToken){
        JWTActiveUser jwtActiveUser = findJWTActiveUserByUserEmailAndJWTToken(email, jwtToken);
        if(jwtActiveUser != null){
            jwtActiveUserRepository.delete(jwtActiveUser);
            jwtTokenBlacklistRepository.save(new JWTTokenBlacklist(jwtToken));
            return true;
        }
        return false;
    }

    public List<CartDTO> findAllCartItemsByUser(String userEmail){
        User user = findUserByEmail(userEmail);
        List<CartDTO> cartDTOS = new ArrayList<>();
        if(user != null){
            List<CartItem> cartItems = cartItemRepository.findAllCartItemsByUser(user);
            for (CartItem cartItem : cartItems){
                cartDTOS.add(ClassMapper.mapToCartDTO(cartItem));
            }
        }
        return cartDTOS.isEmpty() ? null : cartDTOS;
    }

    public String processPayment(PaymentDTO paymentDTO, User user) {
        RestTemplate restTemplate = new RestTemplate();

        // Create headers with Authorization
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + checkoutSecretKey);

        // Payment data payload
        Map<String, Object> paymentData = new HashMap<>();
        paymentData.put("source", Map.of("type", "card",
                "number", paymentDTO.getCardNumber(),
                "expiry_month", paymentDTO.getExpiryMonth(),
                "expiry_year", paymentDTO.getExpiryYear(),
                "cvv", paymentDTO.getCvv()));
        paymentData.put("amount", paymentDTO.getAmount());
        paymentData.put("currency", "USD");
        paymentData.put("reference", "order_reference_123");
        paymentData.put("processing_channel_id", "pc_tvfe4xvkdobuveig2bc3be3umu");

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(paymentData, headers);

        // Send POST request to Checkout API
        ResponseEntity<String> response = restTemplate.exchange(paymentUrl, HttpMethod.POST, entity, String.class);

        // Handle response from Checkout.com API
        if (response.getStatusCode() == HttpStatus.CREATED) {

            Payment payment = new Payment(paymentDTO.getCardNumber(), paymentDTO.getExpiryMonth(), paymentDTO.getExpiryYear(),
                    paymentDTO.getCvv(), paymentDTO.getAmount(), user);
            paymentRepository.save(payment);

            // Process successful payment response and return it to frontend
            return response.getBody();
        } else {
            return "Error: " + response.getBody();
        }
    }

    public Timestamp returnLastUserPaymentTimestamp(User user){
        List<Timestamp> timestamps =  paymentRepository.findTopPaymentDateByUser(user);
        return timestamps.isEmpty() ? null : timestamps.getFirst();
    }


















}
